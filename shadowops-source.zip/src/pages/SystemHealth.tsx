import { PageHeader } from "@/components/shadowops/AppShell";
import { BrandMark } from "@/components/shadowops/brand";
import { SectionLabel, TONE, ToneDot } from "@/components/shadowops/primitives";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { api } from "@/convex/_generated/api";
import { MEMORY_COUNTS } from "@/lib/shadowops-data";
import { cn } from "@/lib/utils";
import { useAction } from "convex/react";
import { motion } from "framer-motion";
import { Database, Loader2, RefreshCw, ShieldCheck, Unplug } from "lucide-react";
import { useCallback, useEffect, useState } from "react";

/** Mirrors the EngineStatus envelope returned by the hindsight actions. */
interface EngineStatus {
  configured: boolean;
  connected: boolean;
  baseUrl: string;
  bankId: string;
  apiVersion: string | null;
  features: Record<string, boolean> | null;
  error: string | null;
  code: string | null;
}

export default function SystemHealth() {
  const [secondsSinceSync, setSecondsSinceSync] = useState(122);
  const [status, setStatus] = useState<EngineStatus | null>(null);
  const [probing, setProbing] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const getStatus = useAction(api.hindsight.getEngineStatus);
  const ensureBank = useAction(api.hindsight.ensureBank);

  // Probe once on mount. This is a real network call to the Hindsight server,
  // not a decorative badge — an unconfigured key shows as unconfigured.
  const probe = useCallback(async () => {
    setProbing(true);
    try {
      setStatus((await getStatus({})) as EngineStatus);
    } finally {
      setProbing(false);
    }
  }, [getStatus]);

  useEffect(() => {
    void probe();
  }, [probe]);

  useEffect(() => {
    const t = window.setInterval(() => setSecondsSinceSync((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, []);

  const connect = async () => {
    setConnecting(true);
    setNotice(null);
    const res = await ensureBank({});
    setNotice(
      res.ok
        ? `Bank "${res.data.bankId}" is ready.`
        : `Could not create the bank — ${res.error}`,
    );
    await probe();
    setConnecting(false);
  };

  const connected = status?.connected === true;

  const syncLabel =
    secondsSinceSync < 60
      ? `${secondsSinceSync} seconds ago`
      : `${Math.floor(secondsSinceSync / 60)} minutes ago`;

  const metrics = [
    { label: "Ingestion rate", value: "142 memories / hour", tone: "memory" as const, status: "healthy" },
    { label: "Consolidation", value: "Nightly · 02:00 UTC", tone: "memory" as const, status: "healthy" },
    { label: "Pattern engine", value: "4 active analyses", tone: "discovery" as const, status: "running" },
    { label: "Evidence linking", value: "100% coverage", tone: "success" as const, status: "healthy" },
  ];

  return (
    <div className="mx-auto w-full max-w-5xl space-y-6 px-4 py-8 sm:px-6">
      <PageHeader
        eyebrow="System"
        title="Memory Engine Health"
        description="Hindsight infrastructure status. Deliberately kept out of the daily experience — this is the machinery underneath."
      />

      <Card className={cn("border-[#22C55E]/25 bg-card/70 shadow-none")}>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Database className="size-4 text-[#8B93F8]" />
            MEMORY ENGINE
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            className={cn(
              "flex flex-wrap items-center gap-3 rounded-lg border px-4 py-3",
              connected
                ? "border-[#22C55E]/25 bg-[#22C55E]/10"
                : "border-[#F59E0B]/25 bg-[#F59E0B]/10",
            )}
          >
            {probing ? (
              <Loader2 className="size-3.5 animate-spin text-muted-foreground" />
            ) : connected ? (
              <ToneDot tone="success" pulse />
            ) : (
              <Unplug className="size-3.5 text-[#F59E0B]" />
            )}

            <div className="min-w-0">
              <p
                className={cn(
                  "text-sm font-semibold",
                  connected ? "text-[#4ADE80]" : "text-[#FBBF24]",
                )}
              >
                {probing
                  ? "Contacting memory engine…"
                  : connected
                    ? "Hindsight Connected"
                    : "Hindsight Disconnected"}
              </p>
              {status?.error && !probing && (
                <p className="mt-0.5 text-xs leading-5 text-muted-foreground">{status.error}</p>
              )}
            </div>

            <div className="ml-auto flex items-center gap-2">
              <span className="font-mono text-[10px] text-muted-foreground">
                {status?.connected
                  ? `API ${status.apiVersion ?? "?"} · ${status.bankId}`
                  : (status?.baseUrl ?? "not configured")}
              </span>
              <button
                onClick={connect}
                disabled={connecting || status?.configured === false}
                className="rounded-md border border-border px-2 py-1 font-mono text-[10px] text-muted-foreground transition-colors hover:border-[#6366F1]/50 hover:text-foreground disabled:opacity-40"
              >
                {connecting ? "CONNECTING…" : "CONNECT BANK"}
              </button>
            </div>
          </div>

          {notice && (
            <p className="rounded-lg border border-border bg-surface/60 px-3 py-2 font-mono text-[11px] text-muted-foreground">
              {notice}
            </p>
          )}

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatusStat
              label="Memory Status"
              value={probing ? "Probing…" : connected ? "Healthy" : "Offline"}
              tone={connected ? "success" : "neutral"}
            />
            <StatusStat label="Last Sync" value={syncLabel} tone="memory" live={connected} />
            <StatusStat label="Memories" value={MEMORY_COUNTS.total.toLocaleString()} tone="memory" />
            <StatusStat
              label="Engine"
              value={connected ? "Hindsight" : "Local store"}
              tone="neutral"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card/70 shadow-none">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Subsystems</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {metrics.map((m) => (
              <div
                key={m.label}
                className="flex items-center justify-between rounded-lg border border-border bg-surface/60 px-3 py-2.5"
              >
                <div className="flex items-center gap-2.5">
                  <ToneDot tone={m.tone} />
                  <span className="text-sm">{m.label}</span>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[11px] text-secondary-foreground">{m.value}</p>
                  <p className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{m.status}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-border bg-card/70 shadow-none">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Memory composition</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex h-3 w-full overflow-hidden rounded-full">
              {[
                { n: MEMORY_COUNTS.episodic, cls: "bg-[#6366F1]" },
                { n: MEMORY_COUNTS.decisions, cls: "bg-[#5865F2]" },
                { n: MEMORY_COUNTS.workflows, cls: "bg-[#22D3EE]" },
                { n: MEMORY_COUNTS.incidents, cls: "bg-[#EF4444]" },
                { n: MEMORY_COUNTS.outcomes, cls: "bg-[#22C55E]" },
                { n: MEMORY_COUNTS.procedural, cls: "bg-[#4A5568]" },
              ].map((seg, i) => (
                <motion.div
                  key={i}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className={cn("h-full origin-left", seg.cls)}
                  style={{ width: `${(seg.n / MEMORY_COUNTS.total) * 100}%` }}
                />
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2">
              {(
                [
                  ["Episodic", MEMORY_COUNTS.episodic, "memory"],
                  ["Decisions", MEMORY_COUNTS.decisions, "memory"],
                  ["Workflows", MEMORY_COUNTS.workflows, "discovery"],
                  ["Incidents", MEMORY_COUNTS.incidents, "critical"],
                  ["Outcomes", MEMORY_COUNTS.outcomes, "success"],
                  ["Procedural", MEMORY_COUNTS.procedural, "neutral"],
                ] as const
              ).map(([label, count, tone]) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="flex items-center gap-2 font-mono text-[11px] text-muted-foreground">
                    <ToneDot tone={tone} />
                    {label}
                  </span>
                  <span className="font-mono text-[11px] text-secondary-foreground">
                    {count.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 border-t border-border pt-3">
              <div className="flex items-center justify-between font-mono text-[10px] text-muted-foreground">
                <span>RETENTION</span>
                <span className="flex items-center gap-1.5 text-[#4ADE80]">
                  <ShieldCheck className="size-3.5" />
                  Unlimited · organization-owned
                </span>
              </div>
              <div className="mt-2 flex items-center justify-between font-mono text-[10px] text-muted-foreground">
                <span>CONSOLIDATION</span>
                <span className="flex items-center gap-1.5 text-[#8B93F8]">
                  <RefreshCw className="size-3" />
                  Nightly sequence re-index
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="rounded-xl border border-border bg-card/50 p-4">
        <SectionLabel className="mb-1.5">A note on the architecture</SectionLabel>
        <p className="text-xs leading-5 text-muted-foreground">
          The Hindsight memory layer runs underneath ShadowOps. You experience the intelligence —
          patterns, workflows, evidence — without ever touching the storage. This page exists so
          operators can verify the loop is healthy:{" "}
          <span className="font-mono text-[11px] text-[#8B93F8]">
            memory → understanding → action → new memory
          </span>
          .
        </p>
      </div>
    </div>
  );
}

function StatusStat({
  label,
  value,
  tone,
  live = false,
}: {
  label: string;
  value: string;
  tone: "success" | "memory" | "neutral";
  live?: boolean;
}) {
  return (
    <div className={cn("rounded-lg border px-3 py-2.5", TONE[tone].border)}>
      <p className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={cn("mt-1 flex items-center gap-1.5 text-sm font-semibold", TONE[tone].text)}>
        {live && <ToneDot tone="success" pulse className="size-1.5" />}
        {value}
      </p>
    </div>
  );
}
