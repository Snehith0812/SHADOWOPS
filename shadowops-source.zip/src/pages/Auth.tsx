import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShadowLogo } from "@/components/shadowops/ShadowLogo";
import { LoginScene, type FocusMode, type HoverInfo } from "@/components/shadowops3d/LoginScene";
import { AnimatePresence, motion } from "framer-motion";
import { Eye, EyeOff, Loader2, Lock, Mail } from "lucide-react";
import { Suspense, lazy, useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router";

interface AuthProps {
  redirectAfterAuth?: string;
}

function resolveRedirectAfterAuth(returnTo: string | null, fallback = "/dashboard") {
  if (returnTo?.startsWith("/") && !returnTo.startsWith("//")) {
    return returnTo;
  }
  return fallback;
}

const LoginSceneLazy = lazy(() =>
  import("@/components/shadowops3d/LoginScene").then((m) => ({ default: m.LoginScene })),
);

const STATUS = {
  online: { label: "MEMORY SYSTEM ONLINE", dot: "bg-[#22C55E]", text: "text-[#4ADE80]" },
  offline: { label: "MEMORY SYSTEM OFFLINE", dot: "bg-[#EF4444]", text: "text-[#F87171]" },
};

export default function AuthPage(props: AuthProps) {
  return (
    <Suspense fallback={<div className="min-h-screen bg-background" />}>
      <Auth {...props} />
    </Suspense>
  );
}

function Auth({ redirectAfterAuth }: AuthProps) {
  const { isLoading: authLoading, isAuthenticated, signIn } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = resolveRedirectAfterAuth(searchParams.get("returnTo"), redirectAfterAuth);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [focusMode, setFocusMode] = useState<FocusMode>("idle");
  const [authStage, setAuthStage] = useState(0);
  const [hover, setHover] = useState<HoverInfo | null>(null);
  const [webglOk, setWebglOk] = useState(true);
  const [reducedMotion] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const busy = focusMode === "authenticating";
  const webglChecked = useRef(false);

  useEffect(() => {
    if (!authLoading && isAuthenticated) navigate(redirect);
  }, [authLoading, isAuthenticated, navigate, redirect]);

  useEffect(() => {
    if (webglChecked.current) return;
    webglChecked.current = true;
    try {
      const c = document.createElement("canvas");
      setWebglOk(Boolean(c.getContext("webgl2") ?? c.getContext("webgl")));
    } catch {
      setWebglOk(false);
    }
  }, []);

  const runAuth = async (mode: "password" | "guest") => {
    if (busy) return;
    setError(null);
    setFocusMode("authenticating");
    setAuthStage(1);
    try {
      if (mode === "guest") {
        await signIn("anonymous");
      } else {
        await signIn("password", { email, password });
      }
      setAuthStage(2);
      await new Promise((r) => window.setTimeout(r, 900));
      setAuthStage(3);
      await new Promise((r) => window.setTimeout(r, 1000));
      navigate(redirect);
    } catch (e) {
      setAuthStage(0);
      setFocusMode("idle");
      setError(
        e instanceof Error
          ? e.message
          : mode === "guest"
            ? "Demo sign-in failed. Please try again."
            : "Invalid email or password.",
      );
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* 3D gateway (with graceful fallback) */}
      {webglOk ? (
        <div className="absolute inset-0" aria-hidden>
          <LoginSceneLazy
            focus={focusMode}
            authStage={authStage}
            onHover={setHover}
            reducedMotion={reducedMotion}
          />
        </div>
      ) : (
        <div className="absolute inset-0 so-grid-bg" aria-hidden />
      )}
      {/* vignette to keep the card readable */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 70% at 62% 50%, rgba(8,11,18,0.55) 0%, rgba(8,11,18,0.12) 55%, rgba(8,11,18,0.6) 100%)",
        }}
        aria-hidden
      />

      {/* status HUD */}
      <div className="absolute right-5 top-5 z-20 flex items-center gap-2 rounded-full border border-[#202938] bg-[#0D111A]/85 px-3.5 py-1.5 backdrop-blur-md">
        <span className={`size-2 rounded-full ${STATUS.online.dot} so-pulse`} />
        <span className={`font-mono text-[10px] tracking-[0.18em] ${STATUS.online.text}`}>
          {STATUS.online.label}
        </span>
      </div>

      {/* live memory HUD */}
      <div className="absolute left-5 top-5 z-20 hidden rounded-xl border border-[#202938] bg-[#0D111A]/85 px-4 py-3 backdrop-blur-md md:block">
        <p className="font-mono text-[9px] tracking-[0.22em] text-[#8A94A8]">ORGANIZATIONAL MEMORY</p>
        <div className="mt-2 space-y-1.5">
          {[
            { v: "12,842", k: "MEMORIES" },
            { v: "1,284", k: "RELATIONSHIPS" },
            { v: "87", k: "WORKFLOWS" },
          ].map((s) => (
            <div key={s.k} className="flex items-baseline gap-2">
              <span className="font-mono text-sm font-bold text-[#F8FAFC]">{s.v}</span>
              <span className="font-mono text-[9px] tracking-[0.16em] text-[#8A94A8]">{s.k}</span>
            </div>
          ))}
        </div>
      </div>

      {/* hover info card */}
      <AnimatePresence>
        {hover && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none fixed z-30 max-w-[240px] rounded-lg border border-[#26314A] bg-[#0D111A]/95 p-3 shadow-xl backdrop-blur-md"
            style={{ left: Math.min(hover.x + 14, window.innerWidth - 260), top: hover.y + 14 }}
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-discovery">{hover.kind}</p>
            <p className="mt-1 text-xs font-semibold leading-snug text-foreground">{hover.title}</p>
            <div className="mt-1.5 space-y-0.5">
              {hover.lines.map((l) => (
                <p key={l} className="font-mono text-[10px] leading-4 text-muted-foreground">
                  {l}
                </p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* login card — right of center */}
      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-10 lg:justify-end lg:pr-[9vw]">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: authStage >= 2 ? 0.35 : 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-[420px] rounded-2xl border border-[#26314A]/80 bg-[#0D111A]/78 p-7 shadow-[0_24px_80px_rgb(3_6_12_/_0.6)] backdrop-blur-2xl sm:p-8"
        >
          {/* wordmark — crisp HTML text + official glyph */}
          <div className="flex items-center gap-3">
            <ShadowLogo variant="mark" className="h-11 w-11 shrink-0" />
            <div className="leading-none">
              <p className="text-[22px] font-extrabold tracking-tight text-[#F8FAFC]">
                Shadow<span className="so-gradient-text">Ops</span>
              </p>
              <p className="mt-1 font-mono text-[9px] tracking-[0.3em] text-[#8A94A8]">
                WORKFLOW THROUGH MEMORY
              </p>
            </div>
          </div>

          <h1 className="mt-7 text-xl font-bold text-[#F8FAFC]">Welcome back</h1>
          <p className="mt-1 text-sm leading-6 text-[#94A3B8]">
            Access your organizational intelligence workspace.
          </p>

          <form
            className="mt-6 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              runAuth("password");
            }}
          >
            <div>
              <label htmlFor="email" className="mb-1.5 block font-mono text-[10px] tracking-[0.18em] text-[#8A94A8]">
                WORK EMAIL
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[#8A94A8]" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onFocus={() => setFocusMode("email")}
                  onBlur={() => setFocusMode("idle")}
                  placeholder="you@company.com"
                  className="h-11 border-[#26314A] bg-[#080B12]/60 pl-9 text-sm focus-visible:border-[#5865F2] focus-visible:ring-[#5865F2]/25"
                />
              </div>
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="password" className="font-mono text-[10px] tracking-[0.18em] text-[#8A94A8]">
                  PASSWORD
                </label>
                <button
                  type="button"
                  className="font-mono text-[10px] text-discovery hover:underline"
                  onClick={() => setError("Password reset is handled by your administrator.")}
                >
                  Forgot?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[#8A94A8]" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onFocus={() => setFocusMode("password")}
                  onBlur={() => setFocusMode("idle")}
                  placeholder="••••••••••••"
                  className="h-11 border-[#26314A] bg-[#080B12]/60 pl-9 pr-10 text-sm focus-visible:border-[#5865F2] focus-visible:ring-[#5865F2]/25"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8A94A8] hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>

            <label className="flex cursor-pointer items-center gap-2 text-xs text-[#94A3B8]">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="size-3.5 accent-[#5865F2]"
              />
              Remember me
            </label>

            {error && (
              <p className="rounded-lg border border-[#EF4444]/30 bg-[#EF4444]/10 px-3 py-2 text-xs text-[#F87171]" role="alert">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={busy}
              className="h-11 w-full bg-[#5865F2] text-sm font-semibold tracking-wide text-white hover:bg-[#5865F2]/90"
            >
              {busy ? (
                <>
                  <Loader2 className="size-4 animate-spin" /> AUTHENTICATING…
                </>
              ) : (
                "SIGN IN"
              )}
            </Button>
          </form>

          <div className="my-5 flex items-center gap-3">
            <span className="h-px flex-1 bg-[#202938]" />
            <span className="font-mono text-[9px] tracking-[0.24em] text-[#8A94A8]">OR</span>
            <span className="h-px flex-1 bg-[#202938]" />
          </div>

          <Button
            type="button"
            variant="outline"
            disabled={busy}
            onClick={() => runAuth("guest")}
            className="h-11 w-full border-[#26314A] bg-transparent text-sm font-semibold text-[#F8FAFC] hover:bg-[#5865F2]/10"
          >
            EXPLORE DEMO
          </Button>

          <div className="mt-6 flex items-center justify-center gap-2 border-t border-[#202938] pt-4">
            <span className="size-1.5 rounded-full bg-[#22C55E] so-pulse" />
            <span className="font-mono text-[9px] tracking-[0.2em] text-[#8A94A8]">
              HINDSIGHT MEMORY · CONNECTED
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
